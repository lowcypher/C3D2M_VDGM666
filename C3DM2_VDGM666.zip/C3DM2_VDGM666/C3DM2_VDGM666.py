#####################################################################################
#
# Nome: C3DM2_VDGM666
# Autor: C3DM2
# Data: 2023-02-05
# Script: Junção de dois scrips Python o C3DM2 e VDGM666
# Funções: tratar arquivos CSV e XLS(X) para importação em MySQL
#
#####################################################################################
#
# Nome: VDGM666
# Autor: C3DM2
# Data: 2023-01-31
# Finalidde: importar N arquivos xls ou xlsx para um banco MySQL.
#
# Problema encontrado:
# Um script pequeno (tá ficou meio grande para o que faz, mas azar, vai ficar assim mesmo!)
# que tem a finalidade de importar dados de vários xexelentos (planilhas para os usuários)
# para um banco MySQL ou MariaDB (depende de sua preferência)
#
# Solução aplicada (neste momento):
#
# Um problema gravíssimo em xexelentos (não é o único problema, mas é um dos graves) é a não
# padronização dos arquivos, como os headers (cabeçalhos).
# Neste caso mesmo os headers estando com caracteres especiais, ao menos estão padronizados
# com os tipos e nomes iguais. Então facilitou um pouco.
#
# Para esse script o autor assume que o ambiente esteja com as dependências satisfeitas
# Existem as dependências Python e de sistema como o MySQL instalado e configurado
# Isto posto, segue: 
#
# 1 - Deixar todos os arquivos xexelentos (xls ou xlsx, fique atendo a isso) num diretório junto com este script;
# 2 - Utilizar este script pelo terminal no diretório dos arquivos. Ex: /home/eudeus/xexelentos/python3 script.py
# 3 - O script faz a seguinte rotina:
#   a - lê os arquivos xls ou xlsx;
#   b - mescla todos arquivo em sequencia ;
#   c - salva em arquivo xlsx (ex: todos666.xlsx);
#   d - troca os caracteres especiais e maiúsculos por caracteres minúsculos - somente do header;
#   e - salva com outro nome já ajustado (ex: 666.xlsx);
#   f - o sqlalchemy se conecta ao MySQL;
#   g - cria o banco e acessa o mesmo;
#   h - acessa o arquivo gerado o 666.xlsx e lê a aba Sheet1;
#   i - cria a tabela com o nome que escolher (ex: tabeladoxexelento);
#   j - cria os campos da tabela e insere os dados;
#   k - o mysql.connector acesso o banco e tabela e faz ajustes na tabela como:
#   k.1 - elimina a coluna index (gerada pelo xexelento) cria a coluna id com primary key e auto increment;
#   k.2 - como criar um campo coloca-o no final da tabela, o ultimo ajuste é trazer para a primeira posição
#           o campo id.
#   l - Se não houve erros no processo, o banco estará pronto e com os dados. Aí é fazer os front end para acessos.
#
#
#   Mario Medeiros (C3DM2) - 2023-01-31
#
#####################################################################################
#                                                                                   #
#####################################################################################
# Nome:
# Data: 2023-02-02
# Autor: C3DM2
#
# Finalidade: script para estudo
# Divide um arquivo csv com 50 mil linhas em 50 arquivos com mil linhas cada, e extensao csv
# Insere o header cada um dos arquivos gerados
# Converte cada arquivo csv para xlsx
# Em seguida chama o arquivo VDGM666 onde executa as rotinas para tratar os xlsx
# e inserir no banco.
# E também ajusta a coluna ID da tabela gerada
#
# Obs: neste script atual, estão os dois juntos, não havendo a necessidade
# de chamar o script Python externo. 
#
#   Mario Medeiros (C3DM2) - 2023-02-02
#
#####################################################################################

# Ignorando warnings do Python sobre mudanças
# nas próximas versões dos módulos
import warnings
warnings.filterwarnings("ignore")

#importando modulos e bibliotecas necessárias - primeiro bloco de código - C3DM2
import pandas as pd
import os
from glob import glob
import subprocess

# executa o comando split do Shell Linux que divide o aquivo CSV de 50 mil linhas
# em um outros arquivos de 1000 linhas cada. Esse é o pdrão do comando split
# para não haver conflitos na execução dos demais comandos
# adicionei a extensão txt para diferenciar dos demais e não entrar na lista
# de arquivos a serem tratados posteriormente
os.system('split --additional-suffix=.csv 50milnomes.csv.txt lista_nomes')

# chama o comando sed do Shell Linux que insere o header em todos os arquivos CSV.
os.system('for x in *.csv; do sed -i "1 i\\first_name;last_name;job;email;phone_number" "$x"; done ')

# faz o loop em busca dos arquivos CSV do diretório corrente e gera seus respecitivos
# arquivos XLSX com headers e sem index.
for csv_file in glob("*.csv"):
    print(csv_file)
    df = pd.read_csv(csv_file, sep=';', on_bad_lines='skip')
    xlsx_file = os.path.splitext(csv_file)[0] + '.xlsx'
    df.to_excel(xlsx_file, index=None, header=True)

#importando modulos e bibliotecas necessárias - segundo bloco de código - VDGM666
import pandas as pd
import glob
from pickle import FALSE
from sqlalchemy import create_engine
from sqlalchemy_utils import database_exists, create_database
import mysql.connector

# caminho/diretorio onde estao os arquivos xls ou xlsx ou csv
path = "."

# arquivos no caminho/diretorio
file_list = glob.glob(path + "/*.xlsx")

# lista de arquivos que a mesclar.
excl_list = []

for file in file_list:
	excl_list.append(pd.read_excel(file))

# cria um novo dataframe para armazenar os xexelentos mesclados
excl_merged = pd.DataFrame()

for excl_file in excl_list:

# adicionando dados usando o excl_merged dataframe.
	excl_merged = excl_merged.append(
	excl_file, ignore_index=True)

# exporta o dataframe dentro de um xexelento com o nome que quiser
excl_merged.to_excel('todos666.xlsx', index=False)

df = pd.read_excel('todos666.xlsx')

# troca os caracteres epeciais do header do xexelento
# obvio que é uma gambiarra tosca!
# se não gostou, então faz melhor e me manda o código!
# como o arquivo é pequeno
# neste caso, somente os 50 mil registros e 6 colunas, então serve. Azar O Seu!

df.columns = df.columns.str.replace('[ ]','_')
df.columns = df.columns.str.replace('[-]','_')
df.columns = df.columns.str.replace('[â]','a')
df.columns = df.columns.str.replace('[Â]','A')
df.columns = df.columns.str.replace('[ã]','a')
df.columns = df.columns.str.replace('[ê]','e')
df.columns = df.columns.str.replace('[Ê]','E')
df.columns = df.columns.str.replace('[ã]','a')
df.columns = df.columns.str.replace('[á]','a')
df.columns = df.columns.str.replace('[é]','e')
df.columns = df.columns.str.replace('[õ]','o')
df.columns = df.columns.str.replace('[ô]','o')
df.columns = df.columns.str.replace('[ó]','o')
df.columns = df.columns.str.replace('[Ó]','o')
df.columns = df.columns.str.replace('[ç]','c')
df.columns = df.columns.str.replace('[Ç]','C')
df.columns = df.columns.str.replace('[A]','a')
df.columns = df.columns.str.replace('[B]','b')
df.columns = df.columns.str.replace('[C]','c')
df.columns = df.columns.str.replace('[D]','d')
df.columns = df.columns.str.replace('[E]','e')
df.columns = df.columns.str.replace('[F]','f')
df.columns = df.columns.str.replace('[G]','g')
df.columns = df.columns.str.replace('[H]','h')
df.columns = df.columns.str.replace('[I]','i')
df.columns = df.columns.str.replace('[J]','j')
df.columns = df.columns.str.replace('[K]','k')
df.columns = df.columns.str.replace('[L]','l')
df.columns = df.columns.str.replace('[M]','m')
df.columns = df.columns.str.replace('[N]','n')
df.columns = df.columns.str.replace('[O]','o')
df.columns = df.columns.str.replace('[P]','p')
df.columns = df.columns.str.replace('[Q]','q')
df.columns = df.columns.str.replace('[R]','r')
df.columns = df.columns.str.replace('[S]','w')
df.columns = df.columns.str.replace('[T]','t')
df.columns = df.columns.str.replace('[U]','u')
df.columns = df.columns.str.replace('[V]','v')
df.columns = df.columns.str.replace('[W]','w')
df.columns = df.columns.str.replace('[X]','x')
df.columns = df.columns.str.replace('[Y]','y')
df.columns = df.columns.str.replace('[Z]','z')

# escreve no arquivo xexelento todos os ajustes anteriores
df1 = df.to_excel('666.xlsx', index=False)

# inicio do bloco de código que importa arquivo gerado pra o banco

# conecta no banco
engine = create_engine("mysql+pymysql://" + "root" + ":" + "123456" + "@" + "localhost" + ":" + "3306" + "/" + "?" + "charset=utf8mb4")

# cria o banco com o nome especificiado, que nesse teste  é o zz_nomes
# em seguida acessa o banco - o comando "USE zznomes"
with engine.connect() as conn:
    conn.execute(f"CREATE DATABASE IF NOT EXISTS {'zz_nomes'}")
    conn.execute(f"USE {'zz_nomes'}")

conn = engine.connect()

#acessa o arquivo final gerado para importar os dados
excel_file = pd.ExcelFile('666.xlsx')

# busca a aba onde estão os dados
# verifique o nome e deixe o mais simples possível
# sem frescuras no nome
excel_dataframe = excel_file.parse(sheet_name="Sheet1")

# insere os dados do xexelento na tabela do banco
excel_dataframe.to_sql("nomes", conn, if_exists="append")

# ajustando coluna id eliminando coluna index que inicia com zero
mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="123456",
                database="zz_nomes"
              )

mycursor = mydb.cursor()

# comando para remover a coluna index e adicionar coluna id como primary key e autoincrement
mycursor.execute("ALTER TABLE nomes DROP COLUMN `index`, ADD COLUMN id int AUTO_INCREMENT PRIMARY KEY")

# obs: a coluna id fica como ultima coluna ao o ser criada e este
# comando move para a primeira posição, sendo a primeira coluna
mycursor.execute("ALTER TABLE nomes CHANGE id id INT(11) NOT NULL FIRST")

print("")
print("Ajustes finalizados e banco criado. Acesso o banco e verifique!")
print("")
#print("Tecle Enter Para Sair")

#input("")

#########################
#
# Fontes de Pesquisa:
# Fonte: https://www.geeksforgeeks.org/pandas-remove-special-characters-from-column-names/
# Fonte: https://stackoverflow.com/questions/44811523/how-do-i-add-a-column-to-an-existing-excel-file-using-python
# Fonte: https://www.geeksforgeeks.org/how-to-merge-multiple-excel-files-into-a-single-files-with-python/
# Fonte: https://stackoverflow.com/questions/9633114/unix-script-to-remove-the-first-line-of-a-csv-file
# Fonte: https://www.unix.com/shell-programming-and-scripting/260051-insert-new-column-sequence-number-delimiter-comma.html
# Fonte: https://unix.stackexchange.com/questions/99350/how-to-insert-text-before-the-first-line-of-a-file
# Fonte: https://stackoverflow.com/questions/14463277/how-to-disable-python-warnings
#
########################